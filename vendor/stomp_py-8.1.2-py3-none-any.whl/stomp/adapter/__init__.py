"""Non-standard adapters.
"""

import stomp.adapter.multicast
import stomp.adapter.ws
