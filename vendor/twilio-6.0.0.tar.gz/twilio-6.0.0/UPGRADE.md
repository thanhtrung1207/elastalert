# Upgrade Guide

_After `6.0.0` all `MINOR` and `MAJOR` version bumps will have upgrade notes 
posted here._
